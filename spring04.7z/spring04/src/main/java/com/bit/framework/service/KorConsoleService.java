package com.bit.framework.service;

public class KorConsoleService implements ConsoleServiece{
	
	public void sayHello() {
		System.out.println("안녕하세요");
	}
	public void sayHi() {
		System.out.println("안녕");
	}
}
