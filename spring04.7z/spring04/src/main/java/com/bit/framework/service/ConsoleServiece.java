package com.bit.framework.service;

public interface ConsoleServiece {
	
	void sayHello();
	void sayHi();
	
}
