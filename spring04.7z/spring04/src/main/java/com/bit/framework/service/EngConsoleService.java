package com.bit.framework.service;

public class EngConsoleService implements ConsoleServiece{
	
	
	
	public void sayHello() {
		System.out.println("Hello ~~~");
		
	}
	
	public void sayHi() {
		System.out.println("Hi~~");
	}
	
}
